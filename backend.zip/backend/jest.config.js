module.exports = {
    testEnvironment: 'node'
};